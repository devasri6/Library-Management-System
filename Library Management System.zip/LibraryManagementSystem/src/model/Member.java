package model;

public class Member extends Person {
    private String department;
    private String email;

    public Member(int memberId, String name,
                  String department, String email) {
        super(memberId, name);
        this.department = department;
        this.email = email;
    }

    public int getMemberId() {
        return getId();
    }

    public String getDepartment() {
        return department;
    }

    public String getEmail() {
        return email;
    }

    @Override
    public String getRole() {
        return "Library Member";
    }
}