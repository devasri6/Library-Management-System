package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    public static Connection getConnection()
            throws SQLException {

        String url = "jdbc:mysql://localhost:3306/library_db";
        String user = "root";
        String password = "SQL Password";

        return DriverManager.getConnection(url, user, password);
    }
}