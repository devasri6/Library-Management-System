package exception;

public class InvalidMemberException extends Exception {

    private static final long serialVersionUID = 1L;

    public InvalidMemberException(String message) {
        super(message);
    }
}