package service;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.time.LocalDate;
import exception.InvalidMemberException;
import exception.BookNotFoundException;
import exception.BookNotAvailableException;

import util.DBConnection;

public class LibraryService {

    public void issueBook(int bookId, int memberId) {
        String checkSql =
            "UPDATE books SET available_copies = available_copies - 1 " +
            "WHERE book_id = ? AND available_copies > 0";

        String issueSql =
            "INSERT INTO borrow_records " +
            "(book_id, member_id, issue_date, due_date, return_date) " +
            "VALUES (?, ?, ?, ?, NULL)";

        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);
            
            String memberSql = "SELECT member_id FROM members WHERE member_id = ?";

            try (PreparedStatement memberCheck =
                    con.prepareStatement(memberSql)) {

                memberCheck.setInt(1, memberId);

                ResultSet rs = memberCheck.executeQuery();

                if (!rs.next()) {
                    con.rollback();
                    throw new InvalidMemberException(
                        "Invalid Member ID! Please register the member first."
                    );
                }
            }
         // Check whether book exists and copies are available
            String bookSql =
                "SELECT available_copies FROM books WHERE book_id = ?";

            try (PreparedStatement bookCheck = con.prepareStatement(bookSql)) {
                bookCheck.setInt(1, bookId);

                try (ResultSet bookRs = bookCheck.executeQuery()) {
                    if (!bookRs.next()) {
                        con.rollback();
                        throw new BookNotFoundException("Book ID not found!");
                    }

                    if (bookRs.getInt("available_copies") <= 0) {
                        con.rollback();
                        throw new BookNotAvailableException(
                            "No copies available for this book!");
                    }
                }
            }
            
            try (PreparedStatement check =
                     con.prepareStatement(checkSql);
                 PreparedStatement issue =
                     con.prepareStatement(issueSql)) {

                check.setInt(1, bookId);

                if (check.executeUpdate() == 0) {
                    con.rollback();
                    System.out.println(
                        "Book not found or no copies available!");
                    return;
                }

                issue.setInt(1, bookId);
                issue.setInt(2, memberId);
                issue.setDate(3, Date.valueOf(LocalDate.now()));
                issue.setDate(4,
                    Date.valueOf(LocalDate.now().plusDays(14)));

                issue.executeUpdate();
                con.commit();

                System.out.println("Book issued successfully!");

            } catch (SQLException e) {
                con.rollback();
                throw e;
            } finally {
                con.setAutoCommit(true);
            }

        }   catch (BookNotFoundException e) {
            System.out.println("Error: " + e.getMessage());

        } catch (BookNotAvailableException e) {
            System.out.println("Error: " + e.getMessage());

        } catch (InvalidMemberException e) {
            System.out.println("Error: " + e.getMessage());

        } catch (SQLException e) {
            System.out.println("Issue failed: " + e.getMessage());
        }
    }
    public void returnBook(int recordId) {

        String sql = "UPDATE borrow_records " +
                     "SET return_date = ? " +
                     "WHERE record_id = ? AND return_date IS NULL";

        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);

            try (PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setDate(1, Date.valueOf(LocalDate.now()));
                ps.setInt(2, recordId);

                if (ps.executeUpdate() == 0) {
                    con.rollback();
                    System.out.println(
                        "Record not found or book already returned!");
                    return;
                }

                String updateBook =
                    "UPDATE books SET available_copies = " +
                    "available_copies + 1 WHERE book_id = " +
                    "(SELECT book_id FROM borrow_records WHERE record_id = ?)";

                try (PreparedStatement ps2 =
                         con.prepareStatement(updateBook)) {
                    ps2.setInt(1, recordId);
                    ps2.executeUpdate();
                }

                con.commit();
                System.out.println("Book returned successfully!");

            } catch (SQLException e) {
                con.rollback();
                throw e;
            } finally {
                con.setAutoCommit(true);
            }

        } catch (SQLException e) {
            System.out.println("Return failed: " + e.getMessage());
        }
    }
}