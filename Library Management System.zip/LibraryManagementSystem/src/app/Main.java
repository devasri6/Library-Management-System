package app;
import java.util.Scanner;

import dao.BookDAO;
import dao.MemberDAO;
import model.Book;
import model.Member;
import service.LibraryService;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        BookDAO dao = new BookDAO();
        LibraryService service = new LibraryService();
        MemberDAO memberDAO = new MemberDAO();

        int choice;

        do {
            System.out.println("\n===== LIBRARY MANAGEMENT SYSTEM =====");
            System.out.println("1. Add Book");
            System.out.println("2. Register Member");
            System.out.println("3. View Books");
            System.out.println("4. Update Book");
            System.out.println("5. Delete Book");
            System.out.println("6. Issue Book");
            System.out.println("7. Return Book");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");

            if (!sc.hasNextInt()) {
                System.out.println("Invalid input! Please enter a number.");
                sc.nextLine();
                choice = -1;
                continue;
            }

            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

            case 1:
                System.out.print("Enter Book ID: ");
                int id = sc.nextInt();
                sc.nextLine();

                System.out.print("Enter title: ");
                String title = sc.nextLine();

                System.out.print("Enter author: ");
                String author = sc.nextLine();

                System.out.print("Enter total copies: ");
                int total = sc.nextInt();

                Book book = new Book(id, title, author, total);
                dao.addBook(book);
                break;

            case 2:
                System.out.print("Enter Member ID: ");
                int memberId = sc.nextInt();
                sc.nextLine();

                System.out.print("Enter Member Name: ");
                String name = sc.nextLine();

                System.out.print("Enter Department: ");
                String department = sc.nextLine();

                System.out.print("Enter Email: ");
                String email = sc.nextLine();

                Member member = new Member(
                    memberId, name, department, email
                );

                memberDAO.addMember(member);
                break;

            case 3:
                dao.viewBooks();
                break;

            case 4:
                System.out.print("Enter Book ID to update: ");
                int updateId = sc.nextInt();
                sc.nextLine();

                System.out.print("Enter new title: ");
                String newTitle = sc.nextLine();

                System.out.print("Enter new author: ");
                String newAuthor = sc.nextLine();

                System.out.print("Enter total copies: ");
                int newTotal = sc.nextInt();

                System.out.print("Enter available copies: ");
                int available = sc.nextInt();

                dao.updateBook(updateId, newTitle, newAuthor,
                               newTotal, available);
                break;

            case 5:
                System.out.print("Enter Book ID to delete: ");
                dao.deleteBook(sc.nextInt());
                break;

            case 6:
                System.out.print("Enter Book ID: ");
                int bookId = sc.nextInt();

                System.out.print("Enter Member ID: ");
                int memberId2 = sc.nextInt();

                service.issueBook(bookId, memberId2);
                break;

            case 7:
                System.out.print("Enter Borrow Record ID: ");
                service.returnBook(sc.nextInt());
                break;

            case 0:
                System.out.println("Thank you!");
                break;

            default:
                System.out.println("Invalid choice!");
        }
        } while (choice != 0);

        sc.close();
    }
}