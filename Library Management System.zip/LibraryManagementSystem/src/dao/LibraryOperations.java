package dao;

import model.Book;

public interface LibraryOperations {
    void addBook(Book book);
    void viewBooks();

    void updateBook(int id, String title,
                    String author, int totalCopies,
                    int availableCopies);

    void deleteBook(int id);
}