package dao;

import model.Book;
import util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BookDAO implements LibraryOperations{

    public void addBook(Book book) {
        String sql = "INSERT INTO books " +
            "(book_id, title, author, total_copies, available_copies) " +
            "VALUES (?, ?, ?, ?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, book.getBookId());
            ps.setString(2, book.getTitle());
            ps.setString(3, book.getAuthor());
            ps.setInt(4, book.getTotalCopies());
            ps.setInt(5, book.getAvailableCopies());

            ps.executeUpdate();
            System.out.println("Book saved to MySQL!");

        } catch (SQLException e) {
            System.out.println("Unable to save book: " + e.getMessage());
        }
    }
    public void viewBooks() {
        String sql = "SELECT * FROM books";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                System.out.println("Book ID: " + rs.getInt("book_id"));
                System.out.println("Title: " + rs.getString("title"));
                System.out.println("Author: " + rs.getString("author"));
                System.out.println("Total Copies: " + rs.getInt("total_copies"));
                System.out.println("Available Copies: " + rs.getInt("available_copies"));
                System.out.println("-----------------------");
            }

        } catch (SQLException e) {
            System.out.println("Unable to view books: " + e.getMessage());
        }
    }
    public void updateBook(int id, String title, String author,
            int totalCopies, int availableCopies) {

String sql = "UPDATE books SET title=?, author=?, " +
      "total_copies=?, available_copies=? WHERE book_id=?";

try (Connection con = DBConnection.getConnection();
PreparedStatement ps = con.prepareStatement(sql)) {

ps.setString(1, title);
ps.setString(2, author);
ps.setInt(3, totalCopies);
ps.setInt(4, availableCopies);
ps.setInt(5, id);

int rows = ps.executeUpdate();

if (rows > 0) {
 System.out.println("Book updated successfully!");
} else {
 System.out.println("Book ID not found!");
}

} catch (SQLException e) {
System.out.println("Update failed: " + e.getMessage());
}
}
    public void deleteBook(int id) {
        String sql = "DELETE FROM books WHERE book_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("Book deleted successfully!");
            } else {
                System.out.println("Book ID not found!");
            }

        } catch (SQLException e) {
            System.out.println("Delete failed: " + e.getMessage());
        }
    }
}
