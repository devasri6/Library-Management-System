package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import model.Member;
import util.DBConnection;

public class MemberDAO {

    public void addMember(Member member) {
        String sql = "INSERT INTO members " +
            "(member_id, name, department, email) " +
            "VALUES (?, ?, ?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, member.getMemberId());
            ps.setString(2, member.getName());
            ps.setString(3, member.getDepartment());
            ps.setString(4, member.getEmail());

            ps.executeUpdate();
            System.out.println("Member registered successfully!");

        } catch (SQLException e) {
            System.out.println("Registration failed: "
                    + e.getMessage());
        }
    }
}